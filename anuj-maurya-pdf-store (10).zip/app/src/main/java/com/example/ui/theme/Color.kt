package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1565C0)
val BlueOnPrimary = Color(0xFFFFFFFF)
val BluePrimaryContainer = Color(0xFFDCEBFF)
val BlueOnPrimaryContainer = Color(0xFF001D4D)

val BlueSecondary = Color(0xFF0288D1)
val BlueOnSecondary = Color(0xFFFFFFFF)
val BlueSecondaryContainer = Color(0xFFE1F5FE)
val BlueOnSecondaryContainer = Color(0xFF01579B)

val AmberAccent = Color(0xFFF57C00)
val AmberContainer = Color(0xFFFFF3E0)
val AmberOnContainer = Color(0xFFE65100)

val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF4F7FB)
val CardBackground = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A2130)
val TextSecondary = Color(0xFF5A6B82)
val BorderLight = Color(0xFFE2E8F0)
val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFED6C02)
val ErrorRed = Color(0xFFD32F2F)

val DarkPrimary = Color(0xFF90CAF9)
val DarkBackground = Color(0xFF0D1B2A)
val DarkSurface = Color(0xFF1B263B)
