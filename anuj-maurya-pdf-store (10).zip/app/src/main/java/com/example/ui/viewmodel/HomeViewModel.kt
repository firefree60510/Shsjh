package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AppSettings
import com.example.data.model.PdfItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val pdfs: List<PdfItem> = emptyList(),
    val appSettings: AppSettings = AppSettings(),
    val selectedClass: String = "All", // "All", "Class 10", "Class 9"
    val selectedCategory: String = "All", // "All", "Notes", "Model Papers", "Previous Year Papers", "Important Questions", "Important Papers"
    val searchQuery: String = "",
    val error: String? = null,
    val currentServerUrl: String = ""
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        HomeUiState(currentServerUrl = preferences.serverUrl)
    )
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val settingsResult = repository.getSettings()
            val settings = settingsResult.getOrDefault(AppSettings())

            val pdfsResult = repository.getPdfs(
                boardClass = _uiState.value.selectedClass,
                category = _uiState.value.selectedCategory,
                searchQuery = _uiState.value.searchQuery
            )
            val pdfs = pdfsResult.getOrDefault(emptyList())

            _uiState.update {
                it.copy(
                    isLoading = false,
                    appSettings = settings,
                    pdfs = pdfs,
                    currentServerUrl = preferences.serverUrl
                )
            }
        }
    }

    fun selectClass(className: String) {
        if (_uiState.value.selectedClass == className) return
        _uiState.update { it.copy(selectedClass = className) }
        fetchFilteredPdfs()
    }

    fun selectCategory(category: String) {
        if (_uiState.value.selectedCategory == category) return
        _uiState.update { it.copy(selectedCategory = category) }
        fetchFilteredPdfs()
    }

    fun onSearchQueryChange(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        fetchFilteredPdfs()
    }

    private fun fetchFilteredPdfs() {
        viewModelScope.launch {
            val result = repository.getPdfs(
                boardClass = _uiState.value.selectedClass,
                category = _uiState.value.selectedCategory,
                searchQuery = _uiState.value.searchQuery
            )
            _uiState.update {
                it.copy(pdfs = result.getOrDefault(emptyList()))
            }
        }
    }

    fun updateServerUrl(url: String) {
        preferences.serverUrl = url
        _uiState.update { it.copy(currentServerUrl = preferences.serverUrl) }
        loadData()
    }
}
