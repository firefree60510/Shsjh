package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AdminViewModel
import com.example.util.WhatsAppHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    viewModel: AdminViewModel,
    onBackClick: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showPostPdfDialog by remember { mutableStateOf(false) }
    var showDeleteAllConfirmDialog by remember { mutableStateOf(false) }
    var pdfToDelete by remember { mutableStateOf<PdfItem?>(null) }
    var viewingScreenshotUrl by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uiState.actionSuccessMessage) {
        uiState.actionSuccessMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearActionMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (uiState.isLoggedIn) "Admin: ${uiState.adminName}" else "Admin Portal",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (uiState.isLoggedIn) {
                        IconButton(onClick = { viewModel.loadDashboardData() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = Color.White
                            )
                        }
                        IconButton(onClick = { viewModel.logout() }) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = "Logout",
                                tint = Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D47A1),
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            if (uiState.isLoggedIn && uiState.selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showPostPdfDialog = true },
                    containerColor = AmberAccent,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("admin_post_pdf_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Post New PDF")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Post PDF Image", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!uiState.isLoggedIn) {
                AdminLoginForm(
                    isLoading = uiState.isLoading,
                    loginError = uiState.loginError,
                    onLogin = { u, p -> viewModel.login(u, p) }
                )
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Admin Navigation Tabs (Scrollable)
                    ScrollableTabRow(
                        selectedTabIndex = uiState.selectedTab,
                        containerColor = Color.White,
                        contentColor = BluePrimary,
                        edgePadding = 12.dp
                    ) {
                        Tab(
                            selected = uiState.selectedTab == 0,
                            onClick = { viewModel.selectTab(0) },
                            text = { Text("Orders (${uiState.orders.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = uiState.selectedTab == 1,
                            onClick = { viewModel.selectTab(1) },
                            text = { Text("Posts (${uiState.pdfs.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = uiState.selectedTab == 2,
                            onClick = { viewModel.selectTab(2) },
                            text = { Text("YouTube Banners (${uiState.appSettings.banners.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                        Tab(
                            selected = uiState.selectedTab == 3,
                            onClick = { viewModel.selectTab(3) },
                            text = { Text("UPI & Links", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        )
                    }

                    when (uiState.selectedTab) {
                        0 -> AdminOrdersTab(
                            uiState = uiState,
                            onFilterChange = { viewModel.filterOrders(it) },
                            onApproveOrder = { order ->
                                viewModel.updateOrderStatus(order.orderId, "Approved", "Payment verified by Admin. PDF will be sent to WhatsApp.")
                            },
                            onRejectOrder = { order ->
                                viewModel.updateOrderStatus(order.orderId, "Rejected", "Payment verification failed. Please contact on WhatsApp.")
                            },
                            onViewScreenshot = { url ->
                                if (!url.isNullOrEmpty()) {
                                    viewingScreenshotUrl = url
                                } else {
                                    Toast.makeText(context, "No screenshot available", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                        1 -> AdminManagePdfsTab(
                            pdfs = uiState.pdfs,
                            isLoading = uiState.isLoading,
                            onAddNewClick = { showPostPdfDialog = true },
                            onDeleteClick = { pdf -> pdfToDelete = pdf },
                            onDeleteAllClick = { showDeleteAllConfirmDialog = true }
                        )
                        2 -> AdminBannersManagerTab(
                            initialBanners = uiState.appSettings.banners,
                            isLoading = uiState.isLoading,
                            onSaveBanners = { banners -> viewModel.saveBanners(banners) }
                        )
                        3 -> AdminQrAndLinksTab(
                            settings = uiState.appSettings,
                            isLoading = uiState.isLoading,
                            onSaveSettings = { upiId, upiName, announcement, whatsapp, youtube, telegram, qrUri, logoUri ->
                                viewModel.saveSettings(upiId, upiName, announcement, whatsapp, youtube, telegram, qrUri, logoUri)
                            }
                        )
                    }
                }
            }
        }
    }

    // Post PDF Dialog (Upload Single Cover Image + Details)
    if (showPostPdfDialog) {
        PostPdfDialog(
            onDismiss = { showPostPdfDialog = false },
            onPost = { title, boardClass, subject, category, price, origPrice, desc, pages, size, year, coverUri ->
                viewModel.postNewPdf(title, boardClass, subject, category, price, origPrice, desc, pages, size, year, coverUri)
                showPostPdfDialog = false
            }
        )
    }

    // Delete Single Confirmation Dialog
    pdfToDelete?.let { pdf ->
        AlertDialog(
            onDismissRequest = { pdfToDelete = null },
            title = { Text("Delete This Post?", fontWeight = FontWeight.Bold, color = ErrorRed) },
            text = { Text("Are you sure you want to permanently delete '${pdf.title}'? It will be removed immediately from user screen and will never reappear.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePdf(pdf.id, pdf.title)
                        pdfToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Delete Post")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { pdfToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete ALL Sample / Default Posts Confirmation Dialog
    if (showDeleteAllConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllConfirmDialog = false },
            title = { Text("Delete ALL Sample Posts?", fontWeight = FontWeight.Bold, color = ErrorRed) },
            text = { Text("यह सभी पुरानी/डिफ़ॉल्ट सैंपल पोस्ट को हमेशा के लिए हटा देगा। इसके बाद केवल आपकी अपलोड की गई पोस्ट्स ही रहेंगी। क्या आप जारी रखना चाहते हैं?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAllPdfs()
                        showDeleteAllConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("Yes, Delete All")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAllConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // View Screenshot Dialog
    viewingScreenshotUrl?.let { url ->
        AlertDialog(
            onDismissRequest = { viewingScreenshotUrl = null },
            title = { Text("Payment Screenshot", fontWeight = FontWeight.Bold) },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = url,
                        contentDescription = "Payment Screenshot",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewingScreenshotUrl = null }) {
                    Text("Close")
                }
            }
        )
    }
}

// ---------------- TAB 0: ORDERS ----------------
@Composable
private fun AdminOrdersTab(
    uiState: com.example.ui.viewmodel.AdminUiState,
    onFilterChange: (String) -> Unit,
    onApproveOrder: (OrderItem) -> Unit,
    onRejectOrder: (OrderItem) -> Unit,
    onViewScreenshot: (String?) -> Unit
) {
    val context = LocalContext.current
    val filterOptions = listOf("All", "Pending", "Approved", "Rejected")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AdminStatsHeader(stats = uiState.stats)
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filterOptions.forEach { status ->
                    val isSelected = uiState.selectedFilter == status
                    FilterChip(
                        selected = isSelected,
                        onClick = { onFilterChange(status) },
                        label = { Text(status, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
        } else if (uiState.orders.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No orders in this category yet.", color = Color.Gray)
                }
            }
        } else {
            items(uiState.orders, key = { it.orderId }) { order ->
                AdminOrderCard(
                    order = order,
                    onViewScreenshot = onViewScreenshot,
                    onApprove = { onApproveOrder(order) },
                    onReject = { onRejectOrder(order) },
                    onOpenWhatsApp = {
                        val msg = if (order.status == "Approved") {
                            "नमस्ते ${order.studentName},\nआपके आर्डर (${order.orderId}) का ₹${order.pdfPrice.toInt()} का पेमेंट वेरिफाई हो गया है।\n\n'${order.pdfTitle}' की PDF फाइल नीचे भेजी जा रही है। धन्यवाद!"
                        } else {
                            "नमस्ते ${order.studentName},\nआपके आर्डर (${order.orderId}) के संबंध में बात करनी है।"
                        }
                        WhatsAppHelper.openChat(context, order.whatsappNumber, msg)
                    }
                )
            }
        }
    }
}

// ---------------- TAB 1: MANAGE POSTS & CLASSES (Post / Delete) ----------------
@Composable
private fun AdminManagePdfsTab(
    pdfs: List<PdfItem>,
    isLoading: Boolean,
    onAddNewClick: () -> Unit,
    onDeleteClick: (PdfItem) -> Unit,
    onDeleteAllClick: () -> Unit
) {
    var selectedClassFilter by remember { mutableStateOf("All") }
    val classes = listOf("All", "Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12")

    val filteredPdfs = if (selectedClassFilter == "All") {
        pdfs
    } else {
        pdfs.filter { it.boardClass.equals(selectedClassFilter, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Class 6 to 12 PDF Material Manager", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1B5E20))
                            Text("Post single images or delete unwanted fake/sample posts permanently", fontSize = 11.sp, color = Color(0xFF2E7D32))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAddNewClick,
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Post", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        if (pdfs.isNotEmpty()) {
                            OutlinedButton(
                                onClick = onDeleteAllClick,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Delete All", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Delete All Sample", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Class Filter Chips
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(classes) { cls ->
                    val isSelected = selectedClassFilter == cls
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedClassFilter = cls },
                        label = { Text(cls, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
        } else if (filteredPdfs.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No posts in $selectedClassFilter. Tap 'New Post' to create one!", color = Color.Gray)
                }
            }
        } else {
            items(filteredPdfs, key = { it.id }) { pdf ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Thumbnail
                        if (!pdf.previewImageUrl.isNullOrEmpty()) {
                            AsyncImage(
                                model = pdf.previewImageUrl,
                                contentDescription = pdf.title,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = Color(0xFFE3F2FD),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "${pdf.boardClass} • ${pdf.subject}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = BluePrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "₹${pdf.price.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SuccessGreen
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = pdf.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Category: ${pdf.category}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        IconButton(
                            onClick = { onDeleteClick(pdf) },
                            modifier = Modifier.testTag("delete_pdf_${pdf.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete PDF",
                                tint = ErrorRed
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- TAB 2: YOUTUBE VIDEO BANNERS MANAGER (Auto-sliding Carousel) ----------------
@Composable
private fun AdminBannersManagerTab(
    initialBanners: List<BannerItem>,
    isLoading: Boolean,
    onSaveBanners: (List<BannerItem>) -> Unit
) {
    val context = LocalContext.current
    val bannerList = remember(initialBanners) {
        mutableStateListOf<BannerItem>().apply {
            addAll(initialBanners.ifEmpty {
                listOf(
                    BannerItem(
                        id = "b1",
                        title = "UP Board 2026 Topper Strategy & Best Notes",
                        youtubeUrl = "https://www.youtube.com/watch?v=3JZ_D3ELwOQ",
                        badgeText = "TOPPER NOTES 2026"
                    ),
                    BannerItem(
                        id = "b2",
                        title = "Class 9, 10, 11 & 12 Board Model Paper Solutions",
                        youtubeUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0",
                        badgeText = "MODEL PAPERS"
                    ),
                    BannerItem(
                        id = "b3",
                        title = "All Subjects Formula & Important Question Bank",
                        youtubeUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                        badgeText = "CRASH COURSE"
                    )
                )
            })
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewCarousel,
                        contentDescription = "Carousel",
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Auto-Sliding YouTube Video Banners",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFFE65100)
                        )
                        Text(
                            text = "Add YouTube video links. App automatically extracts high-res thumbnails and auto-rotates every 2-3 seconds on the home page!",
                            fontSize = 11.sp,
                            color = Color(0xFF8D6E63)
                        )
                    }
                }
            }
        }

        items(bannerList.indices.toList(), key = { it }) { index ->
            val item = bannerList[index]
            var itemTitle by remember(item.title) { mutableStateOf(item.title) }
            var itemUrl by remember(item.youtubeUrl) { mutableStateOf(item.youtubeUrl) }
            var itemBadge by remember(item.badgeText) { mutableStateOf(item.badgeText) }

            val effectiveThumb = remember(itemUrl) {
                val vid = BannerItem.extractYouTubeVideoId(itemUrl)
                if (!vid.isNullOrBlank()) "https://img.youtube.com/vi/$vid/hqdefault.jpg" else ""
            }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = BluePrimary,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Banner #${index + 1}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            // Test YouTube video
                            if (itemUrl.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(itemUrl.trim()))
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Invalid YouTube link", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.OpenInNew,
                                        contentDescription = "Test Video",
                                        tint = BluePrimary
                                    )
                                }
                            }

                            if (bannerList.size > 1) {
                                IconButton(
                                    onClick = { bannerList.removeAt(index) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Remove Banner",
                                        tint = ErrorRed
                                    )
                                }
                            }
                        }
                    }

                    // YouTube Live Thumbnail Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        if (effectiveThumb.isNotBlank()) {
                            AsyncImage(
                                model = effectiveThumb,
                                contentDescription = "YouTube Thumbnail Preview",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Surface(
                                color = Color(0xCCFF0000),
                                shape = CircleShape,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircleFilled,
                                        contentDescription = "Play",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.PlayCircleFilled,
                                    contentDescription = "YouTube",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Paste YouTube URL below to preview thumbnail", fontSize = 11.sp, color = Color.LightGray)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = itemTitle,
                        onValueChange = {
                            itemTitle = it
                            bannerList[index] = item.copy(title = it)
                        },
                        label = { Text("Banner Heading / Title") },
                        placeholder = { Text("e.g. Class 10 Math Topper Strategy 2026") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = itemUrl,
                        onValueChange = {
                            itemUrl = it
                            bannerList[index] = item.copy(youtubeUrl = it)
                        },
                        label = { Text("YouTube Video Link *") },
                        placeholder = { Text("e.g. https://youtu.be/... or https://www.youtube.com/watch?v=...") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.PlayCircleFilled, contentDescription = "YT", tint = Color(0xFFD32F2F))
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = itemBadge,
                        onValueChange = {
                            itemBadge = it
                            bannerList[index] = item.copy(badgeText = it)
                        },
                        label = { Text("Badge Tag (e.g. TOPPER NOTES, MODEL PAPER)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Add Banner Button
        item {
            if (bannerList.size < 6) {
                OutlinedButton(
                    onClick = {
                        bannerList.add(
                            BannerItem(
                                id = java.util.UUID.randomUUID().toString(),
                                title = "New UP Board Preparation Video",
                                youtubeUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                                badgeText = "NEW VIDEO"
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Banner")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Another YouTube Video Banner (${bannerList.size}/6)")
                }
            }
        }

        // Save All Banners Button
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = { onSaveBanners(bannerList.toList()) },
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Icon(imageVector = Icons.Default.Check, contentDescription = "Save")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save YouTube Banners to Home Page", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}

// ---------------- TAB 3: QR, LOGO & SOCIAL LINKS ----------------
@Composable
private fun AdminQrAndLinksTab(
    settings: com.example.data.model.AppSettings,
    isLoading: Boolean,
    onSaveSettings: (
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtube: String,
        telegram: String,
        qrUri: Uri?,
        logoUri: Uri?
    ) -> Unit
) {
    var upiId by remember(settings.upiId) { mutableStateOf(settings.upiId) }
    var upiName by remember(settings.upiName) { mutableStateOf(settings.upiName) }
    var whatsapp by remember(settings.whatsappNumber) { mutableStateOf(settings.whatsappNumber) }
    var announcement by remember(settings.announcement) { mutableStateOf(settings.announcement) }
    var youtubeUrl by remember(settings.youtubeUrl) { mutableStateOf(settings.youtubeUrl) }
    var telegramUrl by remember(settings.telegramUrl) { mutableStateOf(settings.telegramUrl) }
    var selectedQrUri by remember { mutableStateOf<Uri?>(null) }
    var selectedLogoUri by remember { mutableStateOf<Uri?>(null) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedLogoUri = uri
        }
    }

    val qrPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedQrUri = uri
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ================= APP LOGO UPLOAD SECTION =================
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "Logo", tint = BluePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("App Logo / ब्रांड लोगो अपलोड करें", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "यहाँ अपनी गैलरी से अपना मनपसंद लोगो या फोटो अपलोड करें। यह तुरंत होम स्क्रीन के ऊपर दिखना शुरू हो जाएगा!",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .border(2.dp, BluePrimary, CircleShape)
                        .background(Color(0xFFFAFAFA)),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedLogoUri != null) {
                        AsyncImage(
                            model = selectedLogoUri,
                            contentDescription = "New Selected Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else if (!settings.appLogoUrl.isNullOrEmpty()) {
                        AsyncImage(
                            model = settings.appLogoUrl,
                            contentDescription = "Current App Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Image(
                            painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.img_app_icon),
                            contentDescription = "Default Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        logoPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberAccent),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = "Upload Logo")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedLogoUri != null || !settings.appLogoUrl.isNullOrEmpty()) "Change Logo Image / लोगो बदलें" else "Upload Logo Image / लोगो अपलोड करें")
                }
            }
        }

        // UPI QR Code Upload Box
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.QrCode, contentDescription = "QR", tint = BluePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Admin UPI Payment QR Code", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFFBDBDBD), RoundedCornerShape(12.dp))
                        .background(Color(0xFFFAFAFA))
                        .padding(6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedQrUri != null) {
                        AsyncImage(
                            model = selectedQrUri,
                            contentDescription = "New Selected QR",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else if (!settings.upiQrUrl.isNullOrEmpty()) {
                        AsyncImage(
                            model = settings.upiQrUrl,
                            contentDescription = "Current QR Code",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.Image, contentDescription = "No QR", tint = Color.Gray, modifier = Modifier.size(48.dp))
                            Text("No custom QR uploaded", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        qrPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.Image, contentDescription = "Choose QR")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedQrUri != null || !settings.upiQrUrl.isNullOrEmpty()) "Change QR Image" else "Upload QR Code Image")
                }
            }
        }

        // WhatsApp, YouTube & Telegram details
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Link, contentDescription = "Channels", tint = Color(0xFFD32F2F))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("WhatsApp, YouTube & Telegram Links", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("Your Admin WhatsApp Number (10 Digits) *") },
                    placeholder = { Text("e.g. 9876543210") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = youtubeUrl,
                    onValueChange = { youtubeUrl = it },
                    label = { Text("YouTube Channel Link") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.PlayCircleFilled, contentDescription = "YT", tint = Color(0xFFD32F2F))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = telegramUrl,
                    onValueChange = { telegramUrl = it },
                    label = { Text("Telegram Group/Channel Link") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "TG", tint = Color(0xFF0288D1))
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // UPI Account Details
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CurrencyRupee, contentDescription = "UPI", tint = SuccessGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Payment UPI Account", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                OutlinedTextField(
                    value = upiId,
                    onValueChange = { upiId = it },
                    label = { Text("UPI ID (e.g. anujmaurya@upi or PhonePe/Paytm)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = upiName,
                    onValueChange = { upiName = it },
                    label = { Text("UPI Account Holder Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = announcement,
                    onValueChange = { announcement = it },
                    label = { Text("Top Notice Bar text") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Save Button
        Button(
            onClick = {
                onSaveSettings(upiId, upiName, announcement, whatsapp, youtubeUrl, telegramUrl, selectedQrUri, selectedLogoUri)
            },
            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Icon(imageVector = Icons.Default.Check, contentDescription = "Save")
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Logo, QR & Settings", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

// ---------------- DIALOG: POST NEW PDF WITH ALL CLASSES & FREE/PAID OPTION ----------------
@Composable
private fun PostPdfDialog(
    onDismiss: () -> Unit,
    onPost: (
        title: String,
        boardClass: String,
        subject: String,
        category: String,
        price: Double,
        origPrice: Double?,
        desc: String,
        pages: Int,
        size: String,
        year: String,
        coverImageUri: Uri?
    ) -> Unit
) {
    var isFreeMaterial by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var boardClass by remember { mutableStateOf("Class 10") }
    var subject by remember { mutableStateOf("Mathematics") }
    var category by remember { mutableStateOf("Notes") }
    var priceText by remember { mutableStateOf("39") }
    var origPriceText by remember { mutableStateOf("99") }
    var desc by remember { mutableStateOf("") }
    var pagesText by remember { mutableStateOf("50") }
    var sizeText by remember { mutableStateOf("8.5 MB") }
    var yearText by remember { mutableStateOf("2026") }
    var selectedCoverUri by remember { mutableStateOf<Uri?>(null) }

    val coverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedCoverUri = uri
        }
    }

    val allClasses = listOf("Class 6", "Class 7", "Class 8", "Class 9", "Class 10", "Class 11", "Class 12")
    val categories = listOf("Notes", "Model Papers", "Previous Year Papers", "Important Questions", "Important Papers")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Upload New Post (Cover Image)", fontWeight = FontWeight.Bold, color = BluePrimary) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Free vs Paid Toggle Selection
                Text("Pricing Type / सामग्री प्रकार:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilterChip(
                        selected = !isFreeMaterial,
                        onClick = { isFreeMaterial = false },
                        label = { Text("💰 Paid (सशुल्क)", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = isFreeMaterial,
                        onClick = {
                            isFreeMaterial = true
                            priceText = "0"
                        },
                        label = { Text("🎁 FREE (मुफ्त)", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SuccessGreen,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                if (isFreeMaterial) {
                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "✓ यह सामग्री छात्रों के लिए मुफ्त (FREE) रहेगी। कोई पेमेंट या आर्डर अप्रूवल की आवश्यकता नहीं होगी।",
                            color = Color(0xFF2E7D32),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                // Front-page image upload box (Shows on front home page directly)
                Text("Front Page Cover Image (Home Screen पर दिखेगी):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, Color(0xFF90CAF9), RoundedCornerShape(10.dp))
                        .background(Color(0xFFF8FAFC))
                        .clickable {
                            coverPicker.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (selectedCoverUri != null) {
                        AsyncImage(
                            model = selectedCoverUri,
                            contentDescription = "Selected Cover",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = "Add Cover", tint = BluePrimary, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Tap to select front cover image", fontSize = 12.sp, color = BluePrimary, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Topic / Title *") },
                    placeholder = { Text("e.g. Science Chapter 1 Complete Notes") },
                    modifier = Modifier.fillMaxWidth()
                )

                // Board Class Selector (Classes 6 to 12)
                Text("Board Class (कक्षा चुनें):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(allClasses) { cls ->
                        FilterChip(
                            selected = boardClass == cls,
                            onClick = { boardClass = cls },
                            label = { Text(cls, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                // Subject input
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (e.g. Physics, Chemistry, Science, Mathematics)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Text("Category:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                if (!isFreeMaterial) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = priceText,
                            onValueChange = { priceText = it },
                            label = { Text("Price (₹) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = origPriceText,
                            onValueChange = { origPriceText = it },
                            label = { Text("Original Price (₹)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Description (Optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val p = if (isFreeMaterial) 0.0 else (priceText.toDoubleOrNull() ?: 29.0)
                        val op = if (isFreeMaterial) null else origPriceText.toDoubleOrNull()
                        val pages = pagesText.toIntOrNull() ?: 50
                        onPost(title, boardClass, subject, category, p, op, desc, pages, sizeText, yearText, selectedCoverUri)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFreeMaterial) SuccessGreen else BluePrimary
                )
            ) {
                Text(if (isFreeMaterial) "Publish Free Post" else "Publish Paid Post")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ---------------- LOGIN FORM ----------------
@Composable
private fun AdminLoginForm(
    isLoading: Boolean,
    loginError: String?,
    onLogin: (String, String) -> Unit
) {
    var username by remember { mutableStateOf("anuj_admin") }
    var password by remember { mutableStateOf("admin123") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color(0xFFE8EAF6),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin",
                            tint = Color(0xFF0D47A1),
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(text = "Admin Control Portal", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = BluePrimary)
                Text(text = "Upload Images, YouTube Banners & Payments", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(20.dp))

                loginError?.let {
                    Surface(
                        color = Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = it,
                            color = ErrorRed,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = "User") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Lock") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { onLogin(username, password) },
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Login to Admin Panel", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatsHeader(stats: com.example.data.model.AdminStats) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard(
            title = "Total Orders",
            value = "${stats.totalOrders}",
            icon = Icons.Default.ShoppingBag,
            color = BluePrimary,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "Pending",
            value = "${stats.pendingOrders}",
            icon = Icons.Default.PendingActions,
            color = AmberAccent,
            modifier = Modifier.weight(1f)
        )
        StatCard(
            title = "Total Earned",
            value = "₹${stats.totalRevenue.toInt()}",
            icon = Icons.Default.CurrencyRupee,
            color = SuccessGreen,
            modifier = Modifier.weight(1.2f)
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = color)
            Text(text = title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun AdminOrderCard(
    order: OrderItem,
    onViewScreenshot: (String?) -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onOpenWhatsApp: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = order.orderId, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = BluePrimary)
                    Text(text = order.createdAt ?: "", fontSize = 10.sp, color = Color.Gray)
                }
                StatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Spacer(modifier = Modifier.height(8.dp))

            Text(text = order.pdfTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Student: ${order.studentName}", fontSize = 12.sp, color = Color.DarkGray)
                Text(text = "Amount: ₹${order.pdfPrice.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
            }
            Text(text = "WhatsApp: +91 ${order.whatsappNumber}", fontSize = 12.sp, color = Color(0xFF00796B), fontWeight = FontWeight.SemiBold)
            order.utrNumber?.let { utr ->
                Text(text = "UTR / Ref: $utr", fontSize = 11.sp, color = Color(0xFF6A1B9A), fontWeight = FontWeight.Medium)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onViewScreenshot(order.screenshotUrl) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Proof", fontSize = 11.sp)
                }

                Button(
                    onClick = onOpenWhatsApp,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Send PDF", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Send on WA", fontSize = 11.sp)
                }

                if (order.status != "Approved") {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Approve", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
