package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OrderConfirmationScreen
import com.example.ui.screens.OrderStatusScreen
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.PdfDetailScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.OrderStatusViewModel
import com.example.ui.viewmodel.PaymentViewModel
import com.example.ui.viewmodel.PdfDetailViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PdfStoreApp()
            }
        }
    }
}

@Composable
fun PdfStoreApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "home",
        modifier = Modifier.fillMaxSize()
    ) {
        composable("home") {
            val homeViewModel: HomeViewModel = viewModel()
            HomeScreen(
                viewModel = homeViewModel,
                onPdfClick = { pdfId ->
                    navController.navigate("pdf_detail/$pdfId")
                },
                onBuyPdfClick = { pdfId ->
                    navController.navigate("payment/$pdfId")
                },
                onTrackOrdersClick = {
                    navController.navigate("order_status")
                },
                onAdminClick = {
                    navController.navigate("admin_panel")
                }
            )
        }

        composable(
            route = "pdf_detail/{pdfId}",
            arguments = listOf(navArgument("pdfId") { type = NavType.LongType })
        ) { backStackEntry ->
            val pdfId = backStackEntry.arguments?.getLong("pdfId") ?: 0L
            val detailViewModel: PdfDetailViewModel = viewModel()
            PdfDetailScreen(
                pdfId = pdfId,
                viewModel = detailViewModel,
                onBackClick = { navController.popBackStack() },
                onBuyNowClick = { id ->
                    navController.navigate("payment/$id")
                }
            )
        }

        composable(
            route = "payment/{pdfId}",
            arguments = listOf(navArgument("pdfId") { type = NavType.LongType })
        ) { backStackEntry ->
            val pdfId = backStackEntry.arguments?.getLong("pdfId") ?: 0L
            val paymentViewModel: PaymentViewModel = viewModel()
            PaymentScreen(
                pdfId = pdfId,
                viewModel = paymentViewModel,
                onBackClick = { navController.popBackStack() },
                onOrderSubmitted = { orderId, title, price ->
                    val encodedTitle = Uri.encode(title)
                    navController.navigate("order_confirmation/$orderId/$encodedTitle/$price") {
                        popUpTo("home")
                    }
                }
            )
        }

        composable(
            route = "order_confirmation/{orderId}/{pdfTitle}/{price}",
            arguments = listOf(
                navArgument("orderId") { type = NavType.StringType },
                navArgument("pdfTitle") { type = NavType.StringType },
                navArgument("price") { type = NavType.FloatType }
            )
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            val rawTitle = backStackEntry.arguments?.getString("pdfTitle") ?: ""
            val pdfTitle = Uri.decode(rawTitle)
            val price = backStackEntry.arguments?.getFloat("price")?.toDouble() ?: 0.0

            OrderConfirmationScreen(
                orderId = orderId,
                pdfTitle = pdfTitle,
                price = price,
                onTrackOrderClick = {
                    navController.navigate("order_status") {
                        popUpTo("home")
                    }
                },
                onHomeClick = {
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        composable("order_status") {
            val statusViewModel: OrderStatusViewModel = viewModel()
            OrderStatusScreen(
                viewModel = statusViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable("admin_panel") {
            val adminViewModel: com.example.ui.viewmodel.AdminViewModel = viewModel()
            com.example.ui.screens.AdminScreen(
                viewModel = adminViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
