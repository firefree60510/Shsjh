package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object WhatsAppHelper {
    /**
     * Cleans phone number and ensures 91 country code prefix without duplicate + or 91
     */
    fun cleanIndianNumber(rawNumber: String): String {
        val digitsOnly = rawNumber.filter { it.isDigit() }
        return when {
            digitsOnly.length == 10 -> "91$digitsOnly"
            digitsOnly.length == 12 && digitsOnly.startsWith("91") -> digitsOnly
            digitsOnly.length > 10 && digitsOnly.startsWith("0") -> "91" + digitsOnly.drop(1)
            digitsOnly.length == 11 && digitsOnly.startsWith("91") -> "91" + digitsOnly.drop(2)
            else -> digitsOnly
        }
    }

    /**
     * Reliably opens WhatsApp chat with phone number and optional message
     */
    fun openChat(context: Context, rawNumber: String, message: String = "") {
        val cleanedNumber = cleanIndianNumber(rawNumber.ifBlank { "919876543210" })
        if (cleanedNumber.length < 10) {
            Toast.makeText(context, "Invalid WhatsApp Number: $rawNumber", Toast.LENGTH_SHORT).show()
            return
        }

        val encodedMsg = if (message.isNotEmpty()) Uri.encode(message) else ""
        val waMeUrl = if (encodedMsg.isNotEmpty()) {
            "https://wa.me/$cleanedNumber?text=$encodedMsg"
        } else {
            "https://wa.me/$cleanedNumber"
        }

        // Also prepare direct whatsapp:// intent
        val directUri = Uri.parse(
            if (encodedMsg.isNotEmpty()) "whatsapp://send?phone=$cleanedNumber&text=$encodedMsg"
            else "whatsapp://send?phone=$cleanedNumber"
        )

        try {
            // 1. Try direct WhatsApp URI scheme first
            val directIntent = Intent(Intent.ACTION_VIEW, directUri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(directIntent)
            return
        } catch (_: Exception) {}

        try {
            // 2. Try explicit com.whatsapp package with wa.me link
            val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waMeUrl)).apply {
                setPackage("com.whatsapp")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(waIntent)
            return
        } catch (_: Exception) {}

        try {
            // 3. Try explicit com.whatsapp.w4b (WhatsApp Business)
            val waBIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waMeUrl)).apply {
                setPackage("com.whatsapp.w4b")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(waBIntent)
            return
        } catch (_: Exception) {}

        try {
            // 4. Fallback to generic ACTION_VIEW for any browser/app
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waMeUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open WhatsApp: Please install WhatsApp or a Web Browser", Toast.LENGTH_LONG).show()
        }
    }
}
