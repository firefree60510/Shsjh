package com.example.data.remote

import com.example.data.model.ApiResponse
import com.example.data.model.AppSettings
import com.example.data.model.OrderItem
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Query

interface PdfApiService {

    @GET("settings.php")
    suspend fun getSettings(): Response<ApiResponse<AppSettings>>

    @GET("pdfs.php")
    suspend fun getPdfs(
        @Query("class") boardClass: String? = null,
        @Query("category") category: String? = null,
        @Query("search") search: String? = null
    ): Response<ApiResponse<List<PdfItem>>>

    @GET("pdf_details.php")
    suspend fun getPdfDetails(
        @Query("id") id: Long
    ): Response<ApiResponse<PdfItem>>

    @Multipart
    @POST("upload_order.php")
    suspend fun submitOrder(
        @Part screenshot: MultipartBody.Part,
        @Part("pdf_id") pdfId: RequestBody,
        @Part("student_name") studentName: RequestBody,
        @Part("whatsapp_number") whatsappNumber: RequestBody,
        @Part("utr_number") utrNumber: RequestBody? = null
    ): Response<ApiResponse<OrderResponseData>>

    @GET("order_status.php")
    suspend fun getOrderStatus(
        @Query("order_id") orderId: String,
        @Query("whatsapp_number") whatsappNumber: String
    ): Response<ApiResponse<OrderItem>>

    @POST("admin_login.php")
    suspend fun adminLogin(
        @retrofit2.http.Body body: Map<String, String>
    ): Response<ApiResponse<com.example.data.model.AdminLoginResponse>>

    @GET("admin_orders.php")
    suspend fun getAdminOrders(
        @Query("status") status: String? = null
    ): Response<com.example.data.model.AdminOrdersResponse>

    @POST("admin_update_order.php")
    suspend fun updateOrderStatus(
        @retrofit2.http.Body body: Map<String, String>
    ): Response<ApiResponse<Unit>>

    @POST("admin_update_settings.php")
    suspend fun updateAdminSettings(
        @retrofit2.http.Body body: Map<String, String>
    ): Response<ApiResponse<Unit>>
}
