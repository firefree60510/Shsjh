package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FirestoreService(private val context: Context) {

    private val db: FirebaseFirestore? by lazy {
        try {
            val app = if (FirebaseApp.getApps(context).isEmpty()) {
                try {
                    FirebaseApp.initializeApp(context)
                } catch (_: Exception) {
                    try {
                        val options = FirebaseOptions.Builder()
                            .setApplicationId(context.packageName)
                            .setProjectId("anuj-maurya-store")
                            .setApiKey("AIzaSyDefaultClientApiKeyForFirestore")
                            .build()
                        FirebaseApp.initializeApp(context, options)
                    } catch (inner: Exception) {
                        Log.w("FirestoreService", "Fallback FirebaseOptions notice: ${inner.message}")
                        null
                    }
                }
            } else {
                FirebaseApp.getInstance()
            }
            if (app != null) {
                FirebaseFirestore.getInstance(app)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w("FirestoreService", "Firestore client fallback mode: ${e.message}")
            null
        }
    }

    private val SETTINGS_COLLECTION = "app_settings"
    private val SETTINGS_DOC = "global_config"
    private val POSTS_COLLECTION = "posts"
    private val ORDERS_COLLECTION = "orders"

    fun isAvailable(): Boolean = db != null

    // ---------------- APP SETTINGS ----------------
    suspend fun getAppSettings(): Result<AppSettings> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val doc = firestore.collection(SETTINGS_COLLECTION).document(SETTINGS_DOC).get().await()
            if (doc.exists()) {
                val bannersList = (doc.get("banners") as? List<*>)?.mapNotNull { item ->
                    if (item is Map<*, *>) {
                        BannerItem(
                            id = item["id"] as? String ?: java.util.UUID.randomUUID().toString(),
                            title = item["title"] as? String ?: "",
                            youtubeUrl = item["youtubeUrl"] as? String ?: (item["youtube_url"] as? String ?: ""),
                            customImageUrl = item["customImageUrl"] as? String ?: (item["custom_image_url"] as? String),
                            badgeText = item["badgeText"] as? String ?: (item["badge_text"] as? String ?: "WATCH ON YOUTUBE")
                        )
                    } else null
                } ?: emptyList()

                val settings = AppSettings(
                    appName = doc.getString("appName") ?: doc.getString("app_name") ?: "Anuj Maurya",
                    announcement = doc.getString("announcement") ?: "UP Board 2025-26: Classes 6, 7, 8, 9, 10, 11 & 12 Handwritten Notes & Model Papers available!",
                    appLogoUrl = doc.getString("appLogoUrl") ?: doc.getString("app_logo_url"),
                    homeBannerUrl = doc.getString("homeBannerUrl") ?: doc.getString("home_banner_url"),
                    banners = bannersList,
                    upiId = doc.getString("upiId") ?: doc.getString("upi_id") ?: "anujmaurya@upi",
                    upiName = doc.getString("upiName") ?: doc.getString("upi_name") ?: "Anuj Maurya",
                    upiQrUrl = doc.getString("upiQrUrl") ?: doc.getString("upi_qr_url"),
                    whatsappNumber = doc.getString("whatsappNumber") ?: doc.getString("whatsapp_number") ?: "919876543210",
                    youtubeUrl = doc.getString("youtubeUrl") ?: doc.getString("youtube_url") ?: "https://youtube.com/@anujmauryapdf",
                    telegramUrl = doc.getString("telegramUrl") ?: doc.getString("telegram_url") ?: "https://t.me/anujmauryapdf",
                    paymentInstructions = doc.getString("paymentInstructions") ?: doc.getString("payment_instructions")
                        ?: "1. Pay exact amount using UPI ID or QR Code\n2. Take a screenshot of the successful transaction\n3. Upload screenshot with your WhatsApp number\n4. Admin will verify and activate your PDF within 1-2 hours."
                )
                Result.success(settings)
            } else {
                Result.failure(Exception("Settings document not found"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveAppSettings(settings: AppSettings): Result<Unit> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val bannersData = settings.banners.map {
                mapOf(
                    "id" to it.id,
                    "title" to it.title,
                    "youtubeUrl" to it.youtubeUrl,
                    "customImageUrl" to it.customImageUrl,
                    "badgeText" to it.badgeText
                )
            }
            val data = hashMapOf<String, Any?>(
                "appName" to settings.appName,
                "announcement" to settings.announcement,
                "appLogoUrl" to settings.appLogoUrl,
                "homeBannerUrl" to settings.homeBannerUrl,
                "banners" to bannersData,
                "upiId" to settings.upiId,
                "upiName" to settings.upiName,
                "upiQrUrl" to settings.upiQrUrl,
                "whatsappNumber" to settings.whatsappNumber,
                "youtubeUrl" to settings.youtubeUrl,
                "telegramUrl" to settings.telegramUrl,
                "paymentInstructions" to settings.paymentInstructions,
                "updatedAt" to System.currentTimeMillis()
            )
            firestore.collection(SETTINGS_COLLECTION).document(SETTINGS_DOC).set(data, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- POSTS / PDF MATERIALS ----------------
    suspend fun getPosts(): Result<List<PdfItem>> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val snapshot = firestore.collection(POSTS_COLLECTION)
                .orderBy("id", Query.Direction.DESCENDING)
                .get()
                .await()

            val list = snapshot.documents.mapNotNull { doc ->
                val id = doc.getLong("id") ?: (doc.id.toLongOrNull() ?: 0L)
                val title = doc.getString("title") ?: return@mapNotNull null
                val boardClass = doc.getString("boardClass") ?: doc.getString("board_class") ?: "Class 10"
                val subject = doc.getString("subject") ?: "General"
                val category = doc.getString("category") ?: "Notes"
                val price = doc.getDouble("price") ?: 29.0
                val originalPrice = doc.getDouble("originalPrice") ?: doc.getDouble("original_price")
                val description = doc.getString("description") ?: ""
                val pagesCount = doc.getLong("pagesCount")?.toInt() ?: doc.getLong("pages_count")?.toInt() ?: 1
                val fileSize = doc.getString("fileSize") ?: doc.getString("file_size") ?: "1.5 MB"
                val year = doc.getString("year") ?: "2026"
                val previewImageUrl = doc.getString("previewImageUrl") ?: doc.getString("preview_image_url")
                val downloadUrl = doc.getString("downloadUrl") ?: doc.getString("download_url")
                val isFeatured = doc.getBoolean("isFeatured") ?: doc.getBoolean("is_featured") ?: true

                PdfItem(
                    id = id,
                    title = title,
                    boardClass = boardClass,
                    subject = subject,
                    category = category,
                    price = price,
                    originalPrice = originalPrice,
                    description = description,
                    pagesCount = pagesCount,
                    fileSize = fileSize,
                    year = year,
                    previewImageUrl = previewImageUrl,
                    downloadUrl = downloadUrl,
                    isFeatured = isFeatured
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun addPost(pdf: PdfItem): Result<Long> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val newId = if (pdf.id > 0) pdf.id else System.currentTimeMillis()
            val data = hashMapOf<String, Any?>(
                "id" to newId,
                "title" to pdf.title,
                "boardClass" to pdf.boardClass,
                "subject" to pdf.subject,
                "category" to pdf.category,
                "price" to pdf.price,
                "originalPrice" to pdf.originalPrice,
                "description" to pdf.description,
                "pagesCount" to pdf.pagesCount,
                "fileSize" to pdf.fileSize,
                "year" to pdf.year,
                "previewImageUrl" to pdf.previewImageUrl,
                "downloadUrl" to pdf.downloadUrl,
                "isFeatured" to pdf.isFeatured,
                "createdAt" to System.currentTimeMillis()
            )
            firestore.collection(POSTS_COLLECTION).document(newId.toString()).set(data).await()
            Result.success(newId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePost(id: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            firestore.collection(POSTS_COLLECTION).document(id.toString()).delete().await()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAllPosts(): Result<Boolean> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val snapshot = firestore.collection(POSTS_COLLECTION).get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- ORDERS ----------------
    suspend fun submitOrder(
        pdfId: Long,
        pdfTitle: String,
        pdfPrice: Double,
        studentName: String,
        whatsappNumber: String,
        utrNumber: String?,
        screenshotBase64OrUrl: String?
    ): Result<OrderResponseData> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val orderId = "AMP-" + (10000 + (Math.random() * 90000).toInt())
            val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())

            val orderData = hashMapOf<String, Any?>(
                "orderId" to orderId,
                "pdfId" to pdfId,
                "pdfTitle" to pdfTitle,
                "pdfPrice" to pdfPrice,
                "studentName" to studentName,
                "whatsappNumber" to whatsappNumber,
                "utrNumber" to (utrNumber ?: ""),
                "screenshotUrl" to (screenshotBase64OrUrl ?: ""),
                "status" to "Pending",
                "statusMessage" to "Order submitted! Admin verification in progress.",
                "downloadUrl" to null,
                "createdAt" to dateStr,
                "timestamp" to System.currentTimeMillis()
            )

            firestore.collection(ORDERS_COLLECTION).document(orderId).set(orderData).await()

            Result.success(
                OrderResponseData(
                    orderId = orderId,
                    status = "Pending",
                    message = "Payment screenshot uploaded successfully! Admin will verify and activate your PDF.",
                    pdfTitle = pdfTitle,
                    price = pdfPrice
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAllOrders(): Result<List<OrderItem>> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val snapshot = firestore.collection(ORDERS_COLLECTION)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()

            val list = snapshot.documents.mapNotNull { doc ->
                val orderId = doc.getString("orderId") ?: doc.id
                val pdfId = doc.getLong("pdfId") ?: 0L
                val pdfTitle = doc.getString("pdfTitle") ?: "PDF Notes"
                val pdfPrice = doc.getDouble("pdfPrice") ?: 29.0
                val studentName = doc.getString("studentName") ?: ""
                val whatsappNumber = doc.getString("whatsappNumber") ?: ""
                val utrNumber = doc.getString("utrNumber")
                val screenshotUrl = doc.getString("screenshotUrl")
                val status = doc.getString("status") ?: "Pending"
                val statusMessage = doc.getString("statusMessage")
                val createdAt = doc.getString("createdAt") ?: ""
                val downloadUrl = doc.getString("downloadUrl")

                OrderItem(
                    orderId = orderId,
                    pdfId = pdfId,
                    pdfTitle = pdfTitle,
                    pdfPrice = pdfPrice,
                    studentName = studentName,
                    whatsappNumber = whatsappNumber,
                    utrNumber = utrNumber,
                    screenshotUrl = screenshotUrl,
                    status = status,
                    statusMessage = statusMessage,
                    createdAt = createdAt,
                    downloadUrl = downloadUrl
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: String,
        message: String?,
        downloadUrl: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val updates = hashMapOf<String, Any?>(
                "status" to newStatus,
                "statusMessage" to (message ?: "Status updated by Admin"),
                "updatedAt" to System.currentTimeMillis()
            )
            if (downloadUrl != null) {
                updates["downloadUrl"] = downloadUrl
            }
            firestore.collection(ORDERS_COLLECTION).document(orderId).update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun checkOrderStatus(orderId: String, whatsappNumber: String): Result<OrderItem> = withContext(Dispatchers.IO) {
        val firestore = db ?: return@withContext Result.failure(Exception("Firestore not initialized"))
        try {
            val doc = firestore.collection(ORDERS_COLLECTION).document(orderId.trim()).get().await()
            if (doc.exists()) {
                val storedWhatsapp = doc.getString("whatsappNumber") ?: ""
                val cleanStored = storedWhatsapp.filter { it.isDigit() }.takeLast(10)
                val cleanInput = whatsappNumber.filter { it.isDigit() }.takeLast(10)

                if (cleanStored == cleanInput || cleanStored.isEmpty()) {
                    val item = OrderItem(
                        orderId = doc.getString("orderId") ?: doc.id,
                        pdfId = doc.getLong("pdfId") ?: 0L,
                        pdfTitle = doc.getString("pdfTitle") ?: "PDF Notes",
                        pdfPrice = doc.getDouble("pdfPrice") ?: 29.0,
                        studentName = doc.getString("studentName") ?: "",
                        whatsappNumber = storedWhatsapp,
                        utrNumber = doc.getString("utrNumber"),
                        screenshotUrl = doc.getString("screenshotUrl"),
                        status = doc.getString("status") ?: "Pending",
                        statusMessage = doc.getString("statusMessage"),
                        createdAt = doc.getString("createdAt") ?: "",
                        downloadUrl = doc.getString("downloadUrl")
                    )
                    Result.success(item)
                } else {
                    Result.failure(Exception("WhatsApp number does not match order record."))
                }
            } else {
                Result.failure(Exception("No order found with ID $orderId"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Convert Uri to compressed Base64 data URI for reliable multi-device cloud display without external storage bucket configuration
    fun uriToBase64(uri: Uri, maxDimension: Int = 800, quality: Int = 75): String? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream) ?: return null

            // Scale down to reduce payload size
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scale = if (width > height) {
                if (width > maxDimension) maxDimension.toFloat() / width else 1f
            } else {
                if (height > maxDimension) maxDimension.toFloat() / height else 1f
            }

            val scaledBitmap = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    originalBitmap,
                    (width * scale).toInt(),
                    (height * scale).toInt(),
                    true
                )
            } else {
                originalBitmap
            }

            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
            val bytes = outputStream.toByteArray()
            val base64String = Base64.encodeToString(bytes, Base64.NO_WRAP)
            "data:image/jpeg;base64,$base64String"
        } catch (e: Exception) {
            Log.e("FirestoreService", "Error converting uri to base64: ${e.message}")
            null
        }
    }
}
