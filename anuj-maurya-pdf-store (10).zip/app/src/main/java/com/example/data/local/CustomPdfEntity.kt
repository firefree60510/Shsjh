package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.PdfItem

@Entity(tableName = "custom_pdfs")
data class CustomPdfEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val boardClass: String, // "Class 9" or "Class 10"
    val subject: String,    // "Mathematics", "Science", "Hindi", etc.
    val category: String,   // "Notes", "Important Papers", "Model Papers", "Previous Year Papers", "Important Questions"
    val price: Double,
    val originalPrice: Double?,
    val description: String?,
    val previewImageUrl: String?,
    val pagesCount: Int = 0,
    val fileSize: String? = null,
    val year: String? = null,
    val isAvailable: Boolean = true,
    val isFeatured: Boolean = false,
    val samplePreviewUrl: String? = null,
    val downloadUrl: String? = null
) {
    fun toPdfItem(): PdfItem = PdfItem(
        id = id,
        title = title,
        boardClass = boardClass,
        subject = subject,
        category = category,
        price = price,
        originalPrice = originalPrice,
        description = description,
        previewImageUrl = previewImageUrl,
        pagesCount = pagesCount,
        fileSize = fileSize,
        year = year,
        isAvailable = isAvailable,
        isFeatured = isFeatured,
        samplePreviewUrl = samplePreviewUrl,
        downloadUrl = downloadUrl
    )

    companion object {
        fun fromPdfItem(item: PdfItem): CustomPdfEntity = CustomPdfEntity(
            id = item.id,
            title = item.title,
            boardClass = item.boardClass,
            subject = item.subject,
            category = item.category,
            price = item.price,
            originalPrice = item.originalPrice,
            description = item.description,
            previewImageUrl = item.previewImageUrl,
            pagesCount = item.pagesCount,
            fileSize = item.fileSize,
            year = item.year,
            isAvailable = item.isAvailable,
            isFeatured = item.isFeatured,
            samplePreviewUrl = item.samplePreviewUrl,
            downloadUrl = item.downloadUrl
        )
    }
}
