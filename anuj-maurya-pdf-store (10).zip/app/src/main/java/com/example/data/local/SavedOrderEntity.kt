package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.OrderItem

@Entity(tableName = "saved_orders")
data class SavedOrderEntity(
    @PrimaryKey val orderId: String,
    val pdfId: Long,
    val pdfTitle: String,
    val pdfPrice: Double,
    val studentName: String,
    val whatsappNumber: String,
    val utrNumber: String?,
    val screenshotUrl: String?,
    val status: String,
    val statusMessage: String?,
    val downloadUrl: String?,
    val createdAt: String
) {
    fun toOrderItem(): OrderItem = OrderItem(
        orderId = orderId,
        pdfId = pdfId,
        pdfTitle = pdfTitle,
        pdfPrice = pdfPrice,
        studentName = studentName,
        whatsappNumber = whatsappNumber,
        utrNumber = utrNumber,
        screenshotUrl = screenshotUrl,
        status = status,
        statusMessage = statusMessage,
        downloadUrl = downloadUrl,
        createdAt = createdAt
    )

    companion object {
        fun fromOrderItem(order: OrderItem): SavedOrderEntity = SavedOrderEntity(
            orderId = order.orderId,
            pdfId = order.pdfId,
            pdfTitle = order.pdfTitle,
            pdfPrice = order.pdfPrice,
            studentName = order.studentName,
            whatsappNumber = order.whatsappNumber,
            utrNumber = order.utrNumber,
            screenshotUrl = order.screenshotUrl,
            status = order.status,
            statusMessage = order.statusMessage,
            downloadUrl = order.downloadUrl,
            createdAt = order.createdAt ?: System.currentTimeMillis().toString()
        )
    }
}
