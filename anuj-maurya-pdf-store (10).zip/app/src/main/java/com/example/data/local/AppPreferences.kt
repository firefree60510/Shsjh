package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.BannerItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("anuj_pdf_store_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val bannerListType = Types.newParameterizedType(List::class.java, BannerItem::class.java)
    private val bannerAdapter = moshi.adapter<List<BannerItem>>(bannerListType)

    companion object {
        private const val KEY_SERVER_URL = "key_server_url"
        private const val KEY_STUDENT_NAME = "key_student_name"
        private const val KEY_WHATSAPP = "key_whatsapp"
        private const val KEY_LAST_ORDER_ID = "key_last_order_id"
        private const val KEY_ADMIN_LOGGED_IN = "key_admin_logged_in"
        private const val KEY_ADMIN_NAME = "key_admin_name"

        // App Settings fields
        private const val KEY_APP_NAME = "key_app_name"
        private const val KEY_ANNOUNCEMENT = "key_announcement"
        private const val KEY_UPI_ID = "key_upi_id"
        private const val KEY_UPI_NAME = "key_upi_name"
        private const val KEY_UPI_QR_URL = "key_upi_qr_url"
        private const val KEY_WHATSAPP_SUPPORT = "key_whatsapp_support"
        private const val KEY_YOUTUBE_URL = "key_youtube_url"
        private const val KEY_TELEGRAM_URL = "key_telegram_url"
        private const val KEY_HOME_BANNER_URL = "key_home_banner_url"
        private const val KEY_HOME_BANNERS_JSON = "key_home_banners_json"
        private const val KEY_APP_LOGO_URL = "key_app_logo_url"
        private const val KEY_INITIAL_SEEDED = "key_initial_seeded"

        const val DEFAULT_SERVER_URL = "https://anujmaurya.com/api/"
    }

    var isInitialSeeded: Boolean
        get() = prefs.getBoolean(KEY_INITIAL_SEEDED, false)
        set(value) = prefs.edit().putBoolean(KEY_INITIAL_SEEDED, value).apply()

    var isAdminLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_ADMIN_LOGGED_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_ADMIN_LOGGED_IN, value).apply()

    var adminName: String
        get() = prefs.getString(KEY_ADMIN_NAME, "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString(KEY_ADMIN_NAME, value).apply()

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value.trim().let {
            if (it.endsWith("/")) it else "$it/"
        }).apply()

    var studentName: String
        get() = prefs.getString(KEY_STUDENT_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_STUDENT_NAME, value).apply()

    var whatsappNumber: String
        get() = prefs.getString(KEY_WHATSAPP, "") ?: ""
        set(value) = prefs.edit().putString(KEY_WHATSAPP, value).apply()

    var lastOrderId: String
        get() = prefs.getString(KEY_LAST_ORDER_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_ORDER_ID, value).apply()

    // Persistent Local App Settings
    var upiId: String
        get() = prefs.getString(KEY_UPI_ID, "anujmaurya@upi") ?: "anujmaurya@upi"
        set(value) = prefs.edit().putString(KEY_UPI_ID, value).apply()

    var upiName: String
        get() = prefs.getString(KEY_UPI_NAME, "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString(KEY_UPI_NAME, value).apply()

    var upiQrUrl: String?
        get() = prefs.getString(KEY_UPI_QR_URL, null)
        set(value) = prefs.edit().putString(KEY_UPI_QR_URL, value).apply()

    var whatsappSupport: String
        get() = prefs.getString(KEY_WHATSAPP_SUPPORT, "919876543210") ?: "919876543210"
        set(value) = prefs.edit().putString(KEY_WHATSAPP_SUPPORT, value).apply()

    var youtubeUrl: String
        get() = prefs.getString(KEY_YOUTUBE_URL, "https://youtube.com/@anujmauryapdf") ?: "https://youtube.com/@anujmauryapdf"
        set(value) = prefs.edit().putString(KEY_YOUTUBE_URL, value).apply()

    var telegramUrl: String
        get() = prefs.getString(KEY_TELEGRAM_URL, "https://t.me/anujmauryapdf") ?: "https://t.me/anujmauryapdf"
        set(value) = prefs.edit().putString(KEY_TELEGRAM_URL, value).apply()

    var announcement: String
        get() = prefs.getString(KEY_ANNOUNCEMENT, "UP Board Exam 2026: Classes 6, 7, 8, 9, 10, 11 & 12 Handwritten Notes & Model Papers available!")
            ?: "UP Board Exam 2026: Classes 6, 7, 8, 9, 10, 11 & 12 Handwritten Notes & Model Papers available!"
        set(value) = prefs.edit().putString(KEY_ANNOUNCEMENT, value).apply()

    var homeBannerUrl: String?
        get() = prefs.getString(KEY_HOME_BANNER_URL, null)
        set(value) = prefs.edit().putString(KEY_HOME_BANNER_URL, value).apply()

    var appLogoUrl: String?
        get() = prefs.getString(KEY_APP_LOGO_URL, null)
        set(value) = prefs.edit().putString(KEY_APP_LOGO_URL, value).apply()

    var homeBanners: List<BannerItem>
        get() {
            val json = prefs.getString(KEY_HOME_BANNERS_JSON, null)
            if (!json.isNullOrBlank()) {
                try {
                    val list = bannerAdapter.fromJson(json)
                    if (!list.isNullOrEmpty()) return list
                } catch (_: Exception) {}
            }
            return defaultBanners
        }
        set(value) {
            try {
                val json = bannerAdapter.toJson(value)
                prefs.edit().putString(KEY_HOME_BANNERS_JSON, json).apply()
            } catch (_: Exception) {}
        }

    val defaultBanners: List<BannerItem>
        get() = listOf(
            BannerItem(
                id = "b1",
                title = "UP Board 2026 Topper Handwritten Notes & Full Strategy",
                youtubeUrl = "https://www.youtube.com/watch?v=3JZ_D3ELwOQ",
                badgeText = "TOPPER NOTES 2026"
            ),
            BannerItem(
                id = "b2",
                title = "Class 9, 10, 11 & 12 Board Model Question Papers Solution",
                youtubeUrl = "https://www.youtube.com/watch?v=9bZkp7q19f0",
                badgeText = "MODEL PAPERS"
            ),
            BannerItem(
                id = "b3",
                title = "All Formulae & Important Questions Crash Course",
                youtubeUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                badgeText = "CRASH COURSE"
            )
        )
}
