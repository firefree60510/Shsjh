<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

try {
    $db = getDbConnection();
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';

    $where = "";
    $params = [];
    if (!empty($status) && strtolower($status) !== 'all') {
        $where = "WHERE `status` = :status";
        $params[':status'] = $status;
    }

    $stmt = $db->prepare("SELECT * FROM `orders` $where ORDER BY `id` DESC");
    $stmt->execute($params);
    $orders = $stmt->fetchAll();

    // Stats
    $totalOrders = (int)$db->query("SELECT COUNT(*) FROM `orders`")->fetchColumn();
    $pendingOrders = (int)$db->query("SELECT COUNT(*) FROM `orders` WHERE `status` = 'Pending'")->fetchColumn();
    $approvedOrders = (int)$db->query("SELECT COUNT(*) FROM `orders` WHERE `status` = 'Approved'")->fetchColumn();
    $totalRevenue = (float)$db->query("SELECT COALESCE(SUM(`pdf_price`), 0) FROM `orders` WHERE `status` = 'Approved'")->fetchColumn();

    sendJsonResponse([
        'success' => true,
        'stats' => [
            'total_orders' => $totalOrders,
            'pending_orders' => $pendingOrders,
            'approved_orders' => $approvedOrders,
            'total_revenue' => $totalRevenue
        ],
        'data' => $orders
    ]);
} catch (Exception $e) {
    sendJsonResponse(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
