<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

try {
    $db = getDbConnection();
    $stmt = $db->query("SELECT * FROM `app_settings` ORDER BY `id` ASC LIMIT 1");
    $settings = $stmt->fetch();

    if (!$settings) {
        $settings = [
            'app_name' => 'Anuj Maurya PDF Store',
            'announcement' => 'UP Board Exam 2025-26 Special: Class 9 & Class 10 Model Papers & Notes are available!',
            'home_banner_url' => '',
            'upi_id' => 'anujmaurya@upi',
            'upi_name' => 'Anuj Maurya',
            'upi_qr_url' => '',
            'whatsapp_number' => '919876543210',
            'youtube_url' => 'https://youtube.com/@anujmauryapdf',
            'telegram_url' => 'https://t.me/anujmauryapdf',
            'payment_instructions' => "1. Pay the exact PDF price using UPI ID or QR Code\n2. Take screenshot\n3. Upload screenshot\n4. Admin verifies within 1-2 hours"
        ];
    }

    sendJsonResponse([
        'success' => true,
        'data' => [
            'app_name' => $settings['app_name'],
            'announcement' => $settings['announcement'],
            'home_banner_url' => $settings['home_banner_url'],
            'upi_id' => $settings['upi_id'],
            'upi_name' => $settings['upi_name'],
            'upi_qr_url' => $settings['upi_qr_url'],
            'whatsapp_number' => $settings['whatsapp_number'],
            'youtube_url' => $settings['youtube_url'],
            'telegram_url' => $settings['telegram_url'],
            'payment_instructions' => $settings['payment_instructions']
        ]
    ]);
} catch (Exception $e) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Error retrieving settings: ' . $e->getMessage()
    ], 500);
}
